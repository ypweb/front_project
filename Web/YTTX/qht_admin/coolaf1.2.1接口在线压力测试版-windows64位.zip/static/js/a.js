(function(){
	var EventUtil = new Object;
    EventUtil.addEventHandler = function(oTarget, sEventType, fnhandler)
    {
        if(oTarget.addEventListener){
            oTarget.addEventListener(sEventType, fnhandler, false);
        }//这里用了对象检测方法判断浏览器,最后的参数false表示事件在捕获阶段,若为true则表示在冒泡阶段
        else if(oTarget.attachEvent){
            oTarget.attachEvent("on" + sEventType, fnhandler);
        } else{
            oTarget["on" + sEventType] = fnhandler;
        }
    }
	
	var d=document.getElementsByClassName("short_url_position");
	for(var i=0;d.length;i++){
		var channel_id =d[i].getAttribute("data-tbl-channel-id");
		var track_id =d[i].getAttribute("data-tbl-track-id");
		var data_url =d[i].getAttribute("data-tbl-url");
		var short_url =d[i].getAttribute("data-tbl-short-url");
		var innerhtml = "<a href ='"+short_url+"' ><img src='"+data_url+"'></img></a>";
		
	    d[i].innerHTML=innerhtml;
		EventUtil.addEventHandler(d[i].children[0],"click",function(channel_id,track_id){
			var JSONP=document.createElement("script");  
		    JSONP.type="text/javascript";  
		    JSONP.src="http://bbs.tongbulv.com/?callback=jsonpCallback&cid="+channel_id+"&tid="+track_id;  
		    document.getElementsByTagName("head")[0].appendChild(JSONP);  
		});
    }
})();